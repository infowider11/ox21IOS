// List dummyLanguages = [
//   {"id": 5, "name": "Chinese"},
//   {"id": 4, "name": "Hindi"},
//   {"id": 3, "name": "English (US)"},
//   {"id": 2, "name": "English (UK)"},
//   {"id": 1, "name": "English (Australia)"}
// ];


// Map dummyCheckDomainResponse ={
//   "status": 1,
//   "message": "success",
//   "data": {
//     "domain": "manish",
//     "length": 6,
//     "status": "Available",
//     "jinCost": 1,
//     "usdCost": 6
//   }
// };

// const Map<String, dynamic> dummyDomainPurchaseSuccessfull = 
// {'domain': 'idtigzixg', 'user_id': 252, 'points': 0, 'btc_cost': 0, 'jin_cost': 0, 'orderID': 640949, 'usd_cost': 6, 'payment_by': 'paypal', 'payment_status': 1, 'transaction_id': 'PAYID-MKI4YIQ1YL938559W6333737', 'expire_time': 1653894962, 'price': '54'};

//  const Map<String, dynamic> dummyUserData = 
//   {'domain': 'idtigzixg', 'user_id': 252, 'points': 0, 'btc_cost': 0, 'jin_cost': 0, 'orderID': 640949, 'usd_cost': 6, 'payment_by': 'paypal', 'payment_status': 1, 'transaction_id': 'PAYID-MKI4YIQ1YL938559W6333737', 'expire_time': '1653894962'};


// const List dummyUserPlayList = [
//   {
//       "id": 63,
//       "user_id": 179,
//       "name": "dummy playlist",
//       "created_at": "2022-05-25T10:05:42.000Z"
//     }
// ];



// List dummyTopBannerPriceList = [
//   {
//       "id": 1,
//       "page_number": 10,
//       "local_price": 1,
//       "global_price": 10,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 2,
//       "page_number": 9,
//       "local_price": 2,
//       "global_price": 20,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 3,
//       "page_number": 8,
//       "local_price": 4,
//       "global_price": 40,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 4,
//       "page_number": 7,
//       "local_price": 8,
//       "global_price": 80,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 5,
//       "page_number": 6,
//       "local_price": 16,
//       "global_price": 160,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 6,
//       "page_number": 5,
//       "local_price": 32,
//       "global_price": 320,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 7,
//       "page_number": 4,
//       "local_price": 64,
//       "global_price": 640,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 8,
//       "page_number": 3,
//       "local_price": 128,
//       "global_price": 1280,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 9,
//       "page_number": 2,
//       "local_price": 256,
//       "global_price": 2560,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     },
//     {
//       "id": 10,
//       "page_number": 1,
//       "local_price": 512,
//       "global_price": 5120,
//       "created_at": "2022-05-02T13:30:16.000Z"
//     }
// ];
// List<Map> dummyChannels = [
//   {
//     'id': '4',
//     'name': 'Doctor specialist',
//     'image': 'http://ox21nft.xyz/images/channels/4.jpg',
//     'created_by': null,
//     'channel_hash': 'f65b4682-ef9a-527b-92d6-79a9ddc36a16',
//     'is_subscribed': 0
//   },
// ];
// List dummyHomePageData = [
//   {
//       "id": 89,
//       'is_banner': false,
//       "user_id": 179,
//       "title": "Quote of the day",
//       "visibility": "public",
//       "time": "2022-05-25 16:27:42.994802",
//       "description": "Lorem Ipsum lorem ipsum",
//       "playlist": [
//         {
//           "id": 63,
//           "user_id": 179,
//           "name": "zhzh",
//           "created_at": "2022-05-25T10:05:42.000Z"
//         }
//       ],
//       "video_type": "videos",
//       "madeForKids": 0,
//       "ageRestricted": 0,
//       "created_at": "2022-05-25T11:24:44.000Z",
//       "video": "https://bafybeifsxvyhpf3cjezkmetak5magbhv74rc732kyuh5nssfwuiew4kyte.ipfs.dweb.link/?filename=image_picker9172607521758513690.mp4",
//       "thumbnail": "https://bafkreie4ucojuuvhlnurxpg6234buhzcdjypfkfbjwzaftgoh26aeq2nui.ipfs.dweb.link/?filename=IMG-20220521-WA0007.jpg",
//       "video_cid": "bafybeifsxvyhpf3cjezkmetak5magbhv74rc732kyuh5nssfwuiew4kyte",
//       "thumbnail_cid": "bafkreie4ucojuuvhlnurxpg6234buhzcdjypfkfbjwzaftgoh26aeq2nui",
//       "channel_id": 124,
//       "channel": [
//         {
//           "id": 124,
//           "name": "Lorem Ipsum",
//           "image": "https://bafkreieh7bzqyyqn3uv72zgmv7qpogy2tbkdm3zccpfvz6zlxxqclbhvim.ipfs.dweb.link/?filename=image_cropper_1653477825305.jpg",
//           "created_by": 179,
//           "channel_hash": "be7dae36-9ea4-58fb-b011-532cb57675eb"
//         }
//       ],
//       "screenshots": [
//         {
//           "id": 108,
//           "post_id": 89,
//           "created_at": "2022-05-25T11:24:46.000Z",
//           "screenshot": "https://bafkreie4ucojuuvhlnurxpg6234buhzcdjypfkfbjwzaftgoh26aeq2nui.ipfs.dweb.link/?filename=IMG-20220521-WA0007.jpg",
//           "screenshot_cid": "bafkreie4ucojuuvhlnurxpg6234buhzcdjypfkfbjwzaftgoh26aeq2nui"
//         }
//       ],
//       "views": 0,
//       "likes": 0,
//       "dislikes": 0,
//       "comments": 0,
//       "is_like": 0,
//       "createdBy": {
//         "id": 179,
//         "uuid": "15d5141c-23e1-5cda-8ea5-8901a1d26f93",
//         "domain": "sjgjafh"
//       }
//     },
//     {
//       "id": 88,
//       'is_banner': false,
//       "user_id": 179,
//       "title": "Ert",
//       "visibility": "public",
//       "time": "2022-05-25 15:34:45.862244",
//       "description": "vuvuvu",
//       "playlist": [
//         {
//           "id": 63,
//           "user_id": 179,
//           "name": "zhzh",
//           "created_at": "2022-05-25T10:05:42.000Z"
//         }
//       ],
//       "video_type": "videos",
//       "madeForKids": 1,
//       "ageRestricted": 0,
//       "created_at": "2022-05-25T10:05:58.000Z",
//       "video": "https://bafybeifsxvyhpf3cjezkmetak5magbhv74rc732kyuh5nssfwuiew4kyte.ipfs.dweb.link/?filename=image_picker1964143646675592264.mp4",
//       "thumbnail": "https://bafkreibi5smrz45ew5s2qjswc7kpludyeaxkwsgnzmjgqjakabv2y5zmpq.ipfs.dweb.link/?filename=IMG-20220523-WA0035.jpg",
//       "video_cid": "bafybeifsxvyhpf3cjezkmetak5magbhv74rc732kyuh5nssfwuiew4kyte",
//       "thumbnail_cid": "bafkreibi5smrz45ew5s2qjswc7kpludyeaxkwsgnzmjgqjakabv2y5zmpq",
//       "channel_id": 112,
//       "channel": [
//         {
//           "id": 112,
//           "name": "My channels",
//           "image": "https://bafkreiazrlqq7a4jfu2fkzqzqeieqle7slgitzl7uxno3gcyglmo2yh334.ipfs.dweb.link/?filename=6.1.%20home%20service%20provider.jpg",
//           "created_by": 4,
//           "channel_hash": "21a0898b-5fdc-5e9e-bedb-b25c8d8e18e6"
//         }
//       ],
//       "screenshots": [
//         {
//           "id": 107,
//           "post_id": 88,
//           "created_at": "2022-05-25T10:06:01.000Z",
//           "screenshot": "https://bafkreibi5smrz45ew5s2qjswc7kpludyeaxkwsgnzmjgqjakabv2y5zmpq.ipfs.dweb.link/?filename=IMG-20220523-WA0035.jpg",
//           "screenshot_cid": "bafkreibi5smrz45ew5s2qjswc7kpludyeaxkwsgnzmjgqjakabv2y5zmpq"
//         }
//       ],
//       "views": 0,
//       "likes": 0,
//       "dislikes": 0,
//       "comments": 0,
//       "is_like": 0,
//       "createdBy": {
//         "id": 179,
//         "uuid": "15d5141c-23e1-5cda-8ea5-8901a1d26f93",
//         "domain": "sjgjafh"
//       }
//     }
// ];




// // List myVideos = [];

// List dummyMyPurchasedDomains = [
//   {
//       "id": 30,
//       "domain": "facebook",
//       "user_id": 179,
//       "usd_cost": 6,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSRRI9E522324L4479564A",
//       "orderID": "177770",
//       "payment_status": 1,
//       "created_at": "2022-05-26T07:14:23.000Z",
//       "updated_at": "2022-05-26T07:14:23.000Z",
//       "expire_time": 1653722064
//     },
//     {
//       "id": 29,
//       "domain": "google.com",
//       "user_id": 179,
//       "usd_cost": 6,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSOFI5CN184952W2698706",
//       "orderID": "275089",
//       "payment_status": 1,
//       "created_at": "2022-05-26T07:07:13.000Z",
//       "updated_at": "2022-05-26T07:07:13.000Z",
//       "expire_time": 1653721633
//     },
//     {
//       "id": 28,
//       "domain": "manishtalreja.dev",
//       "user_id": 179,
//       "usd_cost": 6,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSNRI0CU22121HM141312C",
//       "orderID": "713289",
//       "payment_status": 1,
//       "created_at": "2022-05-26T07:05:51.000Z",
//       "updated_at": "2022-05-26T07:05:51.000Z",
//       "expire_time": 1653721552
//     },
//     {
//       "id": 27,
//       "domain": "instagram.dev",
//       "user_id": 179,
//       "usd_cost": 6,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSMWI6UG91933NW200101U",
//       "orderID": "578490",
//       "payment_status": 1,
//       "created_at": "2022-05-26T07:04:04.000Z",
//       "updated_at": "2022-05-26T07:04:04.000Z",
//       "expire_time": 1653721444
//     },
//     {
//       "id": 26,
//       "domain": "qwsfhbt",
//       "user_id": 179,
//       "usd_cost": 6,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSMDI1HH56325XE385270M",
//       "orderID": "900294",
//       "payment_status": 1,
//       "created_at": "2022-05-26T07:02:47.000Z",
//       "updated_at": "2022-05-26T07:02:47.000Z",
//       "expire_time": 1653721368
//     },
//     {
//       "id": 25,
//       "domain": "qwsfh",
//       "user_id": 179,
//       "usd_cost": 600,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSLQY06Y72585WX564340A",
//       "orderID": "157134",
//       "payment_status": 1,
//       "created_at": "2022-05-26T07:01:35.000Z",
//       "updated_at": "2022-05-26T07:01:35.000Z",
//       "expire_time": 1653721296
//     },
//     {
//       "id": 24,
//       "domain": "gufgh",
//       "user_id": 179,
//       "usd_cost": 600,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSIQA3GM10309WR070881C",
//       "orderID": "702082",
//       "payment_status": 1,
//       "created_at": "2022-05-26T06:55:13.000Z",
//       "updated_at": "2022-05-26T06:55:13.000Z",
//       "expire_time": 1653720914
//     },
//     {
//       "id": 23,
//       "domain": "qwertyu",
//       "user_id": 179,
//       "usd_cost": 6,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSGBA3PW6182778755442E",
//       "orderID": "678907",
//       "payment_status": 1,
//       "created_at": "2022-05-26T06:49:50.000Z",
//       "updated_at": "2022-05-26T06:49:50.000Z",
//       "expire_time": 1653720591
//     },
//     {
//       "id": 22,
//       "domain": "vjjvj",
//       "user_id": 179,
//       "usd_cost": 600,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSE6Q8WK96627YM5697039",
//       "orderID": "824174",
//       "payment_status": 1,
//       "created_at": "2022-05-26T06:47:35.000Z",
//       "updated_at": "2022-05-26T06:47:35.000Z",
//       "expire_time": 1653720455
//     },
//     {
//       "id": 21,
//       "domain": "vjjv",
//       "user_id": 179,
//       "usd_cost": 60000,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSEGY6T0879156S0446907",
//       "orderID": "483463",
//       "payment_status": 1,
//       "created_at": "2022-05-26T06:45:58.000Z",
//       "updated_at": "2022-05-26T06:45:58.000Z",
//       "expire_time": 1653720359
//     },
//     {
//       "id": 20,
//       "domain": "jvbv",
//       "user_id": 179,
//       "usd_cost": 60000,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSDRI1HK070718D9130433",
//       "orderID": "281931",
//       "payment_status": 1,
//       "created_at": "2022-05-26T06:44:32.000Z",
//       "updated_at": "2022-05-26T06:44:32.000Z",
//       "expire_time": 1653720273
//     },
//     {
//       "id": 19,
//       "domain": "xychcj",
//       "user_id": 179,
//       "usd_cost": 6,
//       "jin_cost": 0,
//       "btc_cost": 0,
//       "points": "0",
//       "payment_by": "paypal",
//       "transaction_id": "PAYID-MKHSBGI5FV57611WH867311T",
//       "orderID": "409707",
//       "payment_status": 1,
//       "created_at": "2022-05-26T06:39:32.000Z",
//       "updated_at": "2022-05-26T06:39:32.000Z",
//       "expire_time": 1653719973
//     },
// ];

// List dummyMyPurchasedBanners = [
//   {
//       "id": 3,
//       "uuid": "15d5141c-23e1-5cda-8ea5-8901a1d26f93",
//       "hash": "ysls9pSokp86hMgCVovz30LRjrb/AHEG64CD1rmt3v7",
//       "created_at": "2022-05-26T06:19:01.000Z",
//       "updated_at": "2022-05-26T06:20:05.000Z",
//       "image": "https://bafkreibreqjppiumzgy6b64tn6sedf7tedmzp4b4p23paddfuyszc6lodm.ipfs.dweb.link/?filename=image_cropper_1653545998696.jpg",
//       "language": "Indore",
//       "country": "India",
//       "state": "Madhya Pradesh",
//       "city": "Indore",
//       "channel": "103",
//       "page_number": "1",
//       "user_id": 179,
//       "upload_status": 1
//     },
//     {
//       "id": 2,
//       "uuid": "15d5141c-23e1-5cda-8ea5-8901a1d26f93",
//       "hash": "woc0TSp0L4BrwLP.wJMqdvkzWdzRHAHHQBt.ESAKFvA",
//       "created_at": "2022-05-26T05:42:02.000Z",
//       "updated_at": "2022-05-26T06:12:12.000Z",
//       "image": "https://bafybeifsxvyhpf3cjezkmetak5magbhv74rc732kyuh5nssfwuiew4kyte.ipfs.dweb.link/?filename=image_picker4067157211844381780.mp4",
//       "language": "Indore",
//       "country": "India",
//       "state": "Madhya Pradesh",
//       "city": "Indore",
//       "channel": "111",
//       "page_number": "1",
//       "user_id": 179,
//       "upload_status": 1
//     },
//     {
//       "id": 1,
//       "uuid": "15d5141c-23e1-5cda-8ea5-8901a1d26f93",
//       "hash": "wtpT2uE1I4ZNq75INXiVRBvdbO7tSR2DC7nRFOfIISD",
//       "created_at": "2022-05-25T09:59:02.000Z",
//       "updated_at": "2022-05-26T05:25:56.000Z",
//       "image": "https://bafkreib37durwqkhvdr4fzo6q4ets7pfynkfwpfsdm5fuvsvqsk5ukvvym.ipfs.dweb.link/?filename=image_cropper_1653542749455.jpg",
//       "language": "5",
//       "country": null,
//       "state": null,
//       "city": null,
//       "channel": "1",
//       "page_number": "1",
//       "user_id": 179,
//       "upload_status": 0
//     }
// ];
