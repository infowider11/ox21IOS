import 'package:flutter/cupertino.dart';

const SizedBox hSizedBox05 = SizedBox(width: 5,);
const SizedBox hSizedBox = SizedBox(width: 10,);
const SizedBox hSizedBox2 = SizedBox(width: 20,);
const SizedBox hSizedBox4 = SizedBox(width: 40,);
const SizedBox hSizedBox6 = SizedBox(width: 60,);
const SizedBox hSizedBox8 = SizedBox(width: 80,);
const SizedBox vSizedBox05 = SizedBox(height: 5,);
const SizedBox vSizedBox = SizedBox(height: 10,);
const SizedBox vSizedBox2 = SizedBox(height:20,);
const SizedBox vSizedBox4 = SizedBox(height: 30,);
const SizedBox vSizedBox6 = SizedBox(height: 60,);
const SizedBox vSizedBox8 = SizedBox(height: 80,);