// import 'package:flutter/material.dart';
// import 'package:ox21/constants/colors.dart';
// import 'package:ox21/widgets/CustomTexts.dart';
// import 'package:ox21/widgets/appbar.dart';
//
// class UploadBannerContent extends StatefulWidget {
//   const UploadBannerContent({Key? key}) : super(key: key);
//
//   @override
//   _UploadBannerContentState createState() => _UploadBannerContentState();
// }
//
// class _UploadBannerContentState extends State<UploadBannerContent> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: appBar(context: context),
//       body: Container(
//         padding: EdgeInsets.symmetric(horizontal: 16),
//         child: Column(
//           children: [
//             SubHeadingText(text: 'Add a Link',color: MyColors.primaryColor, ),
//           ],
//         ),
//       ),
//     );
//   }
// }
