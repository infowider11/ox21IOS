library search_map_location;

// export 'package:search_map_location/widget/search_widget.dart';
export 'package:ox21/packages/lib/widget/search_widget.dart';

