class LanguageModal{
  final String name;
  final String code;

  LanguageModal(this.name, this.code);
}